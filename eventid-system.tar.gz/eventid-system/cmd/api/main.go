package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/assure-compliance/eventid/pkg/api"
	"github.com/assure-compliance/eventid/pkg/auth"
	"github.com/assure-compliance/eventid/pkg/producer"
	"github.com/assure-compliance/eventid/pkg/storage"
)

func main() {
	log.Println("Starting EventID API Server...")

	// Load configuration from environment
	config := loadConfig()

	// Initialize auth service
	authService, err := auth.NewAuthService()
	if err != nil {
		log.Fatalf("Failed to create auth service: %v", err)
	}

	// Register platform clients (same as auth server)
	registerClients(authService)

	// Initialize Kafka producer
	producerCfg := producer.Config{
		BootstrapServers: config.KafkaBrokers,
		Topic:            config.KafkaTopic,
	}

	prod, err := producer.NewEventProducer(producerCfg)
	if err != nil {
		log.Fatalf("Failed to create Kafka producer: %v", err)
	}
	defer prod.Close()

	// Initialize event store (optional - for immediate querying)
	storeCfg := storage.Config{
		Host:     config.DBHost,
		Port:     config.DBPort,
		User:     config.DBUser,
		Password: config.DBPassword,
		Database: config.DBName,
		SSLMode:  config.DBSSLMode,
	}

	store, err := storage.NewEventStore(storeCfg)
	if err != nil {
		log.Printf("Warning: Failed to connect to event store: %v", err)
		log.Println("API will continue without query capabilities")
		store = nil
	} else {
		defer store.Close()
	}

	// Create API server
	server := api.NewServer(authService, prod, store)

	// Handle graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
		<-sigCh
		log.Println("Shutting down API server...")
		cancel()
	}()

	// Start server
	addr := ":" + config.Port
	if err := server.Start(addr); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}

type Config struct {
	Port          string
	KafkaBrokers  string
	KafkaTopic    string
	DBHost        string
	DBPort        int
	DBUser        string
	DBPassword    string
	DBName        string
	DBSSLMode     string
}

func loadConfig() Config {
	return Config{
		Port:         getEnv("PORT", "8081"),
		KafkaBrokers: getEnv("KAFKA_BROKERS", "localhost:9092"),
		KafkaTopic:   getEnv("KAFKA_TOPIC", "regulatory-events"),
		DBHost:       getEnv("DB_HOST", "localhost"),
		DBPort:       getEnvInt("DB_PORT", 5432),
		DBUser:       getEnv("DB_USER", "eventid"),
		DBPassword:   getEnv("DB_PASSWORD", "password"),
		DBName:       getEnv("DB_NAME", "eventid_events"),
		DBSSLMode:    getEnv("DB_SSLMODE", "disable"),
	}
}

func registerClients(authService *auth.AuthService) {
	platforms := []struct {
		name     string
		platform string
		role     auth.Role
		scopes   []string
	}{
		{"Claude the Scraper", "scraper", auth.RoleProducer, []string{"events:write"}},
		{"Assure Code", "code", auth.RoleProducer, []string{"events:write", "events:read"}},
		{"Assure Scan", "scan", auth.RoleProducer, []string{"events:write", "events:read"}},
		{"Assure Review", "review", auth.RoleProducer, []string{"events:write", "events:read"}},
	}

	for _, p := range platforms {
		_, _, err := authService.RegisterClient(p.name, p.platform, p.role, p.scopes)
		if err != nil {
			log.Printf("Failed to register client %s: %v\n", p.name, err)
		}
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		var intVal int
		if _, err := fmt.Sscanf(value, "%d", &intVal); err == nil {
			return intVal
		}
	}
	return defaultValue
}
