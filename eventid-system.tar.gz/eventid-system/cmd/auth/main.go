package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"

	"github.com/assure-compliance/eventid/pkg/auth"
	"github.com/gorilla/mux"
	"github.com/rs/cors"
)

func main() {
	log.Println("Starting EventID OAuth 2.0 Authentication Server...")

	// Create auth service
	authService, err := auth.NewAuthService()
	if err != nil {
		log.Fatalf("Failed to create auth service: %v", err)
	}

	// Register default clients for each platform
	registerDefaultClients(authService)

	// Setup HTTP server
	router := mux.NewRouter()

	// OAuth endpoints
	router.HandleFunc("/oauth/token", handleTokenEndpoint(authService)).Methods("POST")
	router.HandleFunc("/.well-known/jwks.json", handleJWKS(authService)).Methods("GET")
	router.HandleFunc("/health", handleHealth()).Methods("GET")

	// Admin endpoints (in production, these would be protected)
	router.HandleFunc("/admin/clients", handleListClients(authService)).Methods("GET")
	router.HandleFunc("/admin/clients", handleRegisterClient(authService)).Methods("POST")

	// CORS
	handler := cors.New(cors.Options{
		AllowedOrigins:   []string{"*"},
		AllowedMethods:   []string{"GET", "POST", "OPTIONS"},
		AllowedHeaders:   []string{"Content-Type", "Authorization"},
		AllowCredentials: true,
	}).Handler(router)

	// Start server
	port := getEnv("PORT", "8082")
	addr := ":" + port

	log.Printf("Auth server listening on %s\n", addr)
	if err := http.ListenAndServe(addr, handler); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}

// handleTokenEndpoint implements OAuth 2.0 token endpoint (Client Credentials Flow)
func handleTokenEndpoint(authService *auth.AuthService) http.HandlerFunc {
	type tokenRequest struct {
		GrantType    string `json:"grant_type"`
		ClientID     string `json:"client_id"`
		ClientSecret string `json:"client_secret"`
		Scope        string `json:"scope"`
	}

	type tokenResponse struct {
		AccessToken string `json:"access_token"`
		TokenType   string `json:"token_type"`
		ExpiresIn   int    `json:"expires_in"`
		Scope       string `json:"scope,omitempty"`
	}

	return func(w http.ResponseWriter, r *http.Request) {
		// Parse form data
		if err := r.ParseForm(); err != nil {
			respondError(w, http.StatusBadRequest, "invalid_request", "Failed to parse form data")
			return
		}

		grantType := r.FormValue("grant_type")
		clientID := r.FormValue("client_id")
		clientSecret := r.FormValue("client_secret")
		scope := r.FormValue("scope")

		// Validate grant type
		if grantType != "client_credentials" {
			respondError(w, http.StatusBadRequest, "unsupported_grant_type", "Only client_credentials grant type is supported")
			return
		}

		// Validate credentials
		client, err := authService.ValidateCredentials(clientID, clientSecret)
		if err != nil {
			respondError(w, http.StatusUnauthorized, "invalid_client", "Invalid client credentials")
			return
		}

		// Generate token
		token, err := authService.GenerateToken(client)
		if err != nil {
			respondError(w, http.StatusInternalServerError, "server_error", "Failed to generate token")
			return
		}

		// Return token
		response := tokenResponse{
			AccessToken: token,
			TokenType:   "Bearer",
			ExpiresIn:   3600, // 1 hour
			Scope:       scope,
		}

		respondJSON(w, http.StatusOK, response)
	}
}

// handleJWKS returns the JSON Web Key Set
func handleJWKS(authService *auth.AuthService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		jwks, err := authService.GetJWKS()
		if err != nil {
			respondError(w, http.StatusInternalServerError, "server_error", "Failed to generate JWKS")
			return
		}

		respondJSON(w, http.StatusOK, jwks)
	}
}

// handleHealth returns service health
func handleHealth() http.HandlerFunc {
	type healthResponse struct {
		Status string `json:"status"`
	}

	return func(w http.ResponseWriter, r *http.Request) {
		respondJSON(w, http.StatusOK, healthResponse{Status: "healthy"})
	}
}

// handleListClients lists all registered clients (admin only)
func handleListClients(authService *auth.AuthService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// In production, verify admin auth
		respondJSON(w, http.StatusOK, map[string]interface{}{
			"message": "Admin endpoint - list clients",
		})
	}
}

// handleRegisterClient registers a new OAuth client (admin only)
func handleRegisterClient(authService *auth.AuthService) http.HandlerFunc {
	type registerRequest struct {
		Name     string   `json:"name"`
		Platform string   `json:"platform"`
		Role     string   `json:"role"`
		Scopes   []string `json:"scopes"`
	}

	return func(w http.ResponseWriter, r *http.Request) {
		var req registerRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			respondError(w, http.StatusBadRequest, "invalid_request", "Invalid JSON")
			return
		}

		client, secret, err := authService.RegisterClient(
			req.Name,
			req.Platform,
			auth.Role(req.Role),
			req.Scopes,
		)
		if err != nil {
			respondError(w, http.StatusInternalServerError, "server_error", "Failed to register client")
			return
		}

		// Return client info (secret only shown once!)
		response := map[string]interface{}{
			"client_id":     client.ClientID,
			"client_secret": secret,
			"name":          client.Name,
			"platform":      client.Platform,
			"role":          client.Role,
			"scopes":        client.Scopes,
		}

		respondJSON(w, http.StatusCreated, response)
	}
}

// registerDefaultClients creates default clients for each platform
func registerDefaultClients(authService *auth.AuthService) {
	platforms := []struct {
		name     string
		platform string
		role     auth.Role
		scopes   []string
	}{
		{"Claude the Scraper", "scraper", auth.RoleProducer, []string{"events:write"}},
		{"Assure Code", "code", auth.RoleProducer, []string{"events:write", "events:read"}},
		{"Assure Scan", "scan", auth.RoleProducer, []string{"events:write", "events:read"}},
		{"Assure Review", "review", auth.RoleProducer, []string{"events:write", "events:read"}},
	}

	for _, p := range platforms {
		client, secret, err := authService.RegisterClient(p.name, p.platform, p.role, p.scopes)
		if err != nil {
			log.Printf("Failed to register client %s: %v\n", p.name, err)
			continue
		}

		log.Printf("Registered client: %s\n", p.name)
		log.Printf("  Client ID: %s\n", client.ClientID)
		log.Printf("  Client Secret: %s\n", secret)
		log.Printf("  Platform: %s\n", client.Platform)
		log.Printf("  Role: %s\n\n", client.Role)
	}
}

// Helper functions
func respondJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func respondError(w http.ResponseWriter, status int, errorCode, description string) {
	response := map[string]string{
		"error":             errorCode,
		"error_description": description,
	}
	respondJSON(w, status, response)
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}
