package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/assure-compliance/eventid/pkg/consumer"
	"github.com/assure-compliance/eventid/pkg/producer"
	"github.com/assure-compliance/eventid/pkg/router"
	"github.com/assure-compliance/eventid/pkg/schema"
	"github.com/assure-compliance/eventid/pkg/storage"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

func main() {
	log.Println("Starting EventID Workspace Monitor...")

	// Load configuration
	config := loadConfig()

	// Initialize workspace store
	workspaceCfg := storage.Config{
		Host:     config.WorkspaceDBHost,
		Port:     config.WorkspaceDBPort,
		User:     config.WorkspaceDBUser,
		Password: config.WorkspaceDBPassword,
		Database: config.WorkspaceDBName,
		SSLMode:  config.DBSSLMode,
	}

	workspaceStore, err := storage.NewWorkspaceStore(workspaceCfg)
	if err != nil {
		log.Fatalf("Failed to create workspace store: %v", err)
	}
	defer workspaceStore.Close()

	// Initialize Kafka producer (for publishing orchestration events)
	producerCfg := producer.Config{
		BootstrapServers: config.KafkaBrokers,
		Topic:            config.KafkaTopic,
	}

	prod, err := producer.NewEventProducer(producerCfg)
	if err != nil {
		log.Fatalf("Failed to create producer: %v", err)
	}
	defer prod.Close()

	// Initialize workspace monitor
	monitorCfg := router.Config{
		WorkspaceStore: workspaceStore,
		Producer:       prod,
		GitHubToken:    config.GitHubToken,
		AssureCodeURL:  config.AssureCodeURL,
		AssureCodeKey:  config.AssureCodeKey,
		MinSeverity:    config.MinSeverity,
	}

	monitor := router.NewWorkspaceMonitor(monitorCfg)

	// Initialize Kafka consumer
	consumerCfg := consumer.Config{
		BootstrapServers: config.KafkaBrokers,
		GroupID:          "eventid-workspace-monitor",
		Topics:           []string{config.KafkaTopic},
		AutoOffsetReset:  "latest", // Only process new events
	}

	eventConsumer, err := consumer.NewEventConsumer(consumerCfg)
	if err != nil {
		log.Fatalf("Failed to create consumer: %v", err)
	}
	defer eventConsumer.Close()

	// Register handlers for relevant event types
	eventConsumer.RegisterHandler(schema.EventRegulatoryUpdate, monitor.HandleRegulatoryEvent)
	eventConsumer.RegisterHandler(schema.EventLawFetched, monitor.HandleRegulatoryEvent)

	// Start metrics server
	go func() {
		http.Handle("/metrics", promhttp.Handler())
		http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(`{"status":"healthy"}`))
		})

		log.Printf("Metrics server listening on :%s\n", config.MetricsPort)
		if err := http.ListenAndServe(":"+config.MetricsPort, nil); err != nil {
			log.Printf("Metrics server error: %v\n", err)
		}
	}()

	// Handle shutdown gracefully
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Println("Shutting down workspace monitor...")
		eventConsumer.Close()
		os.Exit(0)
	}()

	// Start consuming and processing events
	log.Println("Workspace monitor ready, watching for regulatory events...")
	if err := eventConsumer.Start(); err != nil {
		log.Fatalf("Consumer failed: %v", err)
	}
}

type Config struct {
	KafkaBrokers       string
	KafkaTopic         string
	WorkspaceDBHost    string
	WorkspaceDBPort    int
	WorkspaceDBUser    string
	WorkspaceDBPassword string
	WorkspaceDBName    string
	DBSSLMode          string
	GitHubToken        string
	AssureCodeURL      string
	AssureCodeKey      string
	MinSeverity        string
	MetricsPort        string
}

func loadConfig() Config {
	return Config{
		KafkaBrokers:        getEnv("KAFKA_BROKERS", "localhost:9092"),
		KafkaTopic:          getEnv("KAFKA_TOPIC", "regulatory-events"),
		WorkspaceDBHost:     getEnv("WORKSPACE_DB_HOST", "localhost"),
		WorkspaceDBPort:     getEnvInt("WORKSPACE_DB_PORT", 5432),
		WorkspaceDBUser:     getEnv("WORKSPACE_DB_USER", "eventid"),
		WorkspaceDBPassword: getEnv("WORKSPACE_DB_PASSWORD", "password"),
		WorkspaceDBName:     getEnv("WORKSPACE_DB_NAME", "eventid_workspaces"),
		DBSSLMode:           getEnv("DB_SSLMODE", "disable"),
		GitHubToken:         getEnv("GITHUB_TOKEN", ""),
		AssureCodeURL:       getEnv("ASSURE_CODE_API_URL", "http://localhost:3000"),
		AssureCodeKey:       getEnv("ASSURE_CODE_API_KEY", ""),
		MinSeverity:         getEnv("MIN_SEVERITY_THRESHOLD", "HIGH"),
		MetricsPort:         getEnv("METRICS_PORT", "9091"),
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		var intVal int
		if _, err := fmt.Sscanf(value, "%d", &intVal); err == nil {
			return intVal
		}
	}
	return defaultValue
}
