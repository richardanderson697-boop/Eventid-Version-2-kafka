# EventID - Regulatory Compliance Event System

**UUIDv7 Event Bus | Version 1**

Production-grade regulatory compliance event system with automated workspace monitoring for GRC platforms.

## 🎯 Overview

EventID is a bidirectional event bus that connects your compliance platforms (Claude the Scraper, Assure Code, Assure Scan, and Assure Review) through a central Kafka-based event infrastructure. Every action in each platform becomes an immutable event, creating a complete audit trail for compliance workflows.

### Core Capabilities

- **🔐 OAuth 2.0 Authentication**: Machine-to-machine auth with RSA-256 signed JWTs
- **📊 Event Streaming**: Apache Kafka for reliable, ordered event delivery
- **💾 Immutable Audit Log**: PostgreSQL-backed permanent event storage
- **🤖 Intelligent Automation**: Workspace matching with automated spec regeneration
- **🔄 Bidirectional Integration**: Platforms both send and receive events
- **📈 Full Observability**: Prometheus metrics + Grafana dashboards

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐
│ Claude Scraper  │────▶│  OAuth 2.0      │
│  (Regulatory)   │     │  Auth Server    │
└─────────────────┘     └─────────────────┘
                                │
┌─────────────────┐             │ JWT Token
│  Assure Code    │────▶┌───────▼──────────┐
│  (Spec Gen)     │     │   API Gateway    │
└─────────────────┘     │   (Port 8081)    │
                        └───────┬──────────┘
┌─────────────────┐             │
│  Assure Scan    │────▶        │
│  (Auditing)     │     ┌───────▼──────────┐
└─────────────────┘     │  Kafka Event Bus │
                        │  (regulatory-    │
┌─────────────────┐     │   events topic)  │
│  Assure Review  │────▶└───────┬──────────┘
│  (Doc Analysis) │             │
└─────────────────┘      ┌──────┴───────┐
                         │              │
                    ┌────▼────┐   ┌────▼──────────┐
                    │ Event   │   │  Workspace    │
                    │Consumer │   │  Monitor      │
                    │(Audit)  │   │(Orchestration)│
                    └────┬────┘   └────┬──────────┘
                         │             │
                    ┌────▼────┐   ┌────▼──────────┐
                    │Events DB│   │Workspaces DB  │
                    │(Immute) │   │(Configs)      │
                    └─────────┘   └───────────────┘
                                         │
                                  ┌──────┴───────┐
                                  │              │
                            ┌─────▼────┐   ┌─────▼────┐
                            │Spec Regen│   │GitHub PRs│
                            │(ASSURE-  │   │(Automtn) │
                            │ CODE)    │   └──────────┘
                            └──────────┘
```

## 🚀 Quick Start

### Prerequisites

- Docker 24.0+
- Docker Compose
- (Optional) Go 1.21+ for local development

### 1. Clone and Configure

```bash
git clone https://github.com/yourorg/eventid.git
cd eventid

# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env
```

### 2. Start All Services

```bash
# Using Make (recommended)
make run

# Or directly with Docker Compose
docker-compose up -d
```

### 3. Verify Services

```bash
# Check status
make status

# View logs
make logs
```

### 4. Access Services

| Service | URL | Credentials |
|---------|-----|-------------|
| API Server | http://localhost:8081 | OAuth token required |
| Auth Server | http://localhost:8082 | N/A |
| Kafka UI | http://localhost:8080 | None |
| Prometheus | http://localhost:9090 | None |
| Grafana | http://localhost:3001 | admin / admin |

## 📡 Platform Integration

### Obtain OAuth Token

```bash
curl -X POST http://localhost:8082/oauth/token \
  -d "grant_type=client_credentials" \
  -d "client_id=client_scraper_..." \
  -d "client_secret=..." \
  -d "scope=events:write"
```

Response:
```json
{
  "access_token": "eyJhbGciOiJSUzI1NiIs...",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

### Publish Event

```bash
curl -X POST http://localhost:8081/v1/events \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @test-data/test-event.json
```

### Query Events

```bash
curl -X GET "http://localhost:8081/v1/events?platform=scraper&limit=10" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

## 🔄 Event Types

### From Claude the Scraper

```json
{
  "event_type": "regulatory.update",
  "platform": "scraper",
  "jurisdiction": {
    "framework": "HIPAA",
    "region": "US"
  },
  "affected_assets": [
    {"asset_type": "DATABASE"}
  ],
  "risk_context": {
    "change_severity": "HIGH",
    "effective_date": "2025-06-01T00:00:00Z"
  }
}
```

### From Assure Code

```json
{
  "event_type": "code.spec_generated",
  "platform": "code",
  "workspace_id": "ws_healthcare_app",
  "spec_type": "data-retention",
  "framework": "HIPAA",
  "github_pr": {
    "repository": "yourorg/healthcare-app",
    "pr_number": 42,
    "pr_url": "https://github.com/..."
  }
}
```

### From Assure Scan

```json
{
  "event_type": "scan.violation_found",
  "platform": "scan",
  "workspace_id": "ws_healthcare_app",
  "findings": [
    {
      "severity": "HIGH",
      "category": "encryption",
      "description": "Database encryption not enabled"
    }
  ]
}
```

### From Assure Review

```json
{
  "event_type": "review.gap_identified",
  "platform": "review",
  "document_id": "contract_123",
  "document_type": "CONTRACT",
  "compliance_gaps": [
    {
      "severity": "MEDIUM",
      "clause": "Section 4.2",
      "issue": "Missing GDPR data retention clause"
    }
  ]
}
```

## 🎯 Workspace Matching

The Workspace Monitor automatically matches regulatory events to affected workspaces based on:

1. **Framework**: Event framework must be in workspace frameworks
2. **Jurisdiction**: Event region must match workspace region (or GLOBAL)
3. **Assets**: Event affected_assets must overlap with workspace modules

### Example

Event:
- Framework: HIPAA
- Region: US
- Assets: DATABASE, ENCRYPTION

Workspace:
- Frameworks: [HIPAA, SOC2]
- Jurisdiction: US
- Modules: [DATABASE, API, ENCRYPTION]

**Result**: ✅ Match → Triggers spec regeneration

## 🤖 Automated Workflows

When a HIGH or CRITICAL severity event matches a workspace:

1. **Spec Regeneration**: Calls ASSURE-CODE API to regenerate compliance specs
2. **GitHub PR**: Creates pull request with updated specifications
3. **Validation Scan**: Requests Assure Scan to validate changes
4. **Workflow Event**: Publishes workflow status to Kafka

## 📊 Monitoring

### Prometheus Metrics

- `api_requests_total` - API request count by endpoint
- `events_published_total` - Events published by platform/type
- `workspace_events_processed_total` - Events processed by monitor
- `specs_regenerated_total` - Successful spec regenerations
- `github_prs_created_total` - PRs created

### Grafana Dashboards

Access at http://localhost:3001 (admin/admin)

- System Overview
- Event Ingestion Rate
- Workspace Matching Efficiency
- Automation Success Rate

## 🗄️ Database Schema

### Events Table (Immutable)

```sql
CREATE TABLE events (
    event_id UUID UNIQUE NOT NULL,
    event_type VARCHAR(100),
    platform VARCHAR(50),
    timestamp TIMESTAMP WITH TIME ZONE,
    event_data JSONB NOT NULL,
    -- Triggers prevent UPDATE and DELETE
);
```

### Workspaces Table

```sql
CREATE TABLE workspaces (
    workspace_id VARCHAR(255) UNIQUE,
    frameworks JSONB,
    jurisdiction VARCHAR(50),
    modules JSONB,
    github_repo VARCHAR(500),
    active BOOLEAN
);
```

## 🛠️ Development

### Project Structure

```
eventid/
├── cmd/                    # Main applications
│   ├── api/               # REST API server
│   ├── auth/              # OAuth 2.0 server
│   ├── consumer/          # Event consumer (audit)
│   └── workspace-monitor/ # Orchestration service
├── pkg/                   # Shared libraries
│   ├── schema/           # Event definitions
│   ├── producer/         # Kafka producer
│   ├── consumer/         # Kafka consumer
│   ├── storage/          # Database layer
│   ├── auth/             # OAuth implementation
│   ├── api/              # API handlers
│   └── router/           # Workspace monitor
├── scripts/sql/          # Database schemas
├── test-data/            # Sample events
└── docs/                 # Documentation
```

### Build Locally

```bash
# Install dependencies
go mod download

# Build all services
go build ./cmd/api
go build ./cmd/auth
go build ./cmd/consumer
go build ./cmd/workspace-monitor

# Run tests
go test ./...
```

### Make Commands

```bash
make help           # Show available commands
make run            # Start all services
make test-event     # Send test event
make logs           # View logs
make db-connect     # Connect to database
make metrics        # Open Prometheus
make clean          # Remove all containers
```

## 🚢 Deployment

### Kubernetes

```bash
# Deploy all services
kubectl apply -f k8s/

# Check status
kubectl get pods -n eventid
```

### AWS ECS/EKS

See [DEPLOYMENT.md](docs/DEPLOYMENT.md) for detailed instructions.

## 🔒 Security

- **OAuth 2.0**: Client Credentials Flow with RSA-256 JWT
- **Rate Limiting**: 60 requests/minute per client
- **TLS**: All external endpoints use HTTPS in production
- **Immutable Audit Log**: Events cannot be modified or deleted
- **Secrets Management**: Use AWS Secrets Manager or K8s secrets

## 📖 Documentation

- [Architecture Guide](docs/EventID_Architecture.docx)
- [API Reference](docs/EventID_API_Reference.docx)
- [Deployment Guide](docs/EventID_Deployment_Guide.docx)

## 🤝 Contributing

This is an internal AssureCode project. For questions or issues, contact the Compliance Platform Team.

## 📄 License

Proprietary - AssureCode Internal Use

---

**EventID** - Automating Compliance, Ensuring Trust
