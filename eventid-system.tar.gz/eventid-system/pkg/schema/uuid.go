package schema

import (
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"time"
)

// GenerateUUIDv7 creates a time-ordered UUID version 7
// Format: unix_ts_ms (48 bits) + ver (4) + rand_a (12) + var (2) + rand_b (62)
func GenerateUUIDv7() (string, error) {
	// Get current timestamp in milliseconds
	now := time.Now()
	timestamp := now.UnixMilli()
	
	// Create 16-byte array
	uuid := make([]byte, 16)
	
	// Fill first 6 bytes with timestamp (48 bits)
	binary.BigEndian.PutUint64(uuid[0:8], uint64(timestamp)<<16)
	
	// Fill remaining bytes with random data
	if _, err := rand.Read(uuid[6:]); err != nil {
		return "", fmt.Errorf("failed to generate random bytes: %w", err)
	}
	
	// Set version (4 bits) to 7
	uuid[6] = (uuid[6] & 0x0F) | 0x70
	
	// Set variant (2 bits) to RFC 4122
	uuid[8] = (uuid[8] & 0x3F) | 0x80
	
	// Format as UUID string
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		binary.BigEndian.Uint32(uuid[0:4]),
		binary.BigEndian.Uint16(uuid[4:6]),
		binary.BigEndian.Uint16(uuid[6:8]),
		binary.BigEndian.Uint16(uuid[8:10]),
		uuid[10:16],
	), nil
}

// ExtractTimestamp extracts the timestamp from a UUIDv7
func ExtractTimestamp(uuidStr string) (time.Time, error) {
	// Parse UUID string (remove dashes)
	var uuid [16]byte
	_, err := fmt.Sscanf(uuidStr, "%08x-%04x-%04x-%04x-%012x",
		&uuid[0], &uuid[4], &uuid[6], &uuid[8], &uuid[10])
	if err != nil {
		return time.Time{}, fmt.Errorf("invalid UUID format: %w", err)
	}
	
	// Extract timestamp from first 48 bits
	timestamp := int64(binary.BigEndian.Uint64(uuid[0:8]) >> 16)
	
	return time.UnixMilli(timestamp), nil
}
