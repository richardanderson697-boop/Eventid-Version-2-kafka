package schema

import (
	"encoding/json"
	"time"
)

// EventVersion defines the schema version
const EventVersion = 1

// Platform identifies the source system
type Platform string

const (
	PlatformScraper Platform = "scraper"  // Claude the Scraper
	PlatformCode    Platform = "code"     // Assure Code
	PlatformScan    Platform = "scan"     // Assure Scan
	PlatformReview  Platform = "review"   // Assure Review
	PlatformEventID Platform = "eventid"  // EventID orchestration
)

// EventType categorizes the event
type EventType string

const (
	// Scraper events
	EventRegulatoryUpdate EventType = "regulatory.update"
	EventLawFetched       EventType = "regulatory.law_fetched"
	
	// Code events
	EventSpecGenerated   EventType = "code.spec_generated"
	EventSpecUpdated     EventType = "code.spec_updated"
	EventSpecRequested   EventType = "code.spec_requested"
	
	// Scan events
	EventAuditStarted    EventType = "scan.audit_started"
	EventAuditCompleted  EventType = "scan.audit_completed"
	EventViolationFound  EventType = "scan.violation_found"
	EventScanRequested   EventType = "scan.requested"
	
	// Review events
	EventDocumentUploaded EventType = "review.document_uploaded"
	EventComplianceCheck  EventType = "review.compliance_check"
	EventGapIdentified    EventType = "review.gap_identified"
	EventReviewRequested  EventType = "review.requested"
	
	// Orchestration events
	EventWorkflowStarted  EventType = "workflow.started"
	EventWorkflowComplete EventType = "workflow.completed"
	EventValidationStatus EventType = "validation.status"
)

// Severity levels for risk assessment
type Severity string

const (
	SeverityLow      Severity = "LOW"
	SeverityMedium   Severity = "MEDIUM"
	SeverityHigh     Severity = "HIGH"
	SeverityCritical Severity = "CRITICAL"
)

// Framework represents regulatory frameworks
type Framework string

const (
	FrameworkGDPR     Framework = "GDPR"
	FrameworkHIPAA    Framework = "HIPAA"
	FrameworkPCIDSS   Framework = "PCI_DSS"
	FrameworkSOC2     Framework = "SOC2"
	FrameworkISO27001 Framework = "ISO27001"
	FrameworkCCPA     Framework = "CCPA"
	FrameworkNIST     Framework = "NIST"
)

// Region represents geographic jurisdictions
type Region string

const (
	RegionUS     Region = "US"
	RegionEU     Region = "EU"
	RegionUK     Region = "UK"
	RegionAPAC   Region = "APAC"
	RegionGlobal Region = "GLOBAL"
)

// BaseEvent contains fields common to all events
type BaseEvent struct {
	EventID      string    `json:"event_id"`      // UUIDv7
	EventVersion int       `json:"event_version"` // Schema version
	EventType    EventType `json:"event_type"`
	Platform     Platform  `json:"platform"`      // Source platform
	Timestamp    time.Time `json:"timestamp"`
	CorrelationID string   `json:"correlation_id,omitempty"` // Links related events
	UserID       string    `json:"user_id,omitempty"`
}

// RegulatoryEvent represents regulatory changes from Claude the Scraper
type RegulatoryEvent struct {
	BaseEvent
	Jurisdiction  Jurisdiction   `json:"jurisdiction"`
	AffectedAssets []AffectedAsset `json:"affected_assets"`
	RiskContext   RiskContext    `json:"risk_context"`
	Metadata      EventMetadata  `json:"metadata"`
}

// Jurisdiction defines the regulatory scope
type Jurisdiction struct {
	Framework Framework `json:"framework"`
	Region    Region    `json:"region"`
	Authority string    `json:"authority,omitempty"` // e.g., "HHS", "ICO"
}

// AffectedAsset identifies impacted system components
type AffectedAsset struct {
	AssetType   AssetType `json:"asset_type"`
	AssetID     string    `json:"asset_id,omitempty"`
	Description string    `json:"description,omitempty"`
}

// AssetType categorizes system components
type AssetType string

const (
	AssetDatabase         AssetType = "DATABASE"
	AssetAPI              AssetType = "API"
	AssetUserInterface    AssetType = "USER_INTERFACE"
	AssetAuthentication   AssetType = "AUTHENTICATION"
	AssetPaymentProcessing AssetType = "PAYMENT_PROCESSING"
	AssetDataStorage      AssetType = "DATA_STORAGE"
	AssetLogging          AssetType = "LOGGING"
	AssetMonitoring       AssetType = "MONITORING"
	AssetEncryption       AssetType = "ENCRYPTION"
	AssetBackup           AssetType = "BACKUP"
	AssetNetwork          AssetType = "NETWORK"
)

// RiskContext provides severity and urgency information
type RiskContext struct {
	ChangeSeverity     Severity   `json:"change_severity"`
	EffectiveDate      *time.Time `json:"effective_date,omitempty"`
	ComplianceDeadline *time.Time `json:"compliance_deadline,omitempty"`
	ImpactAssessment   string     `json:"impact_assessment,omitempty"`
}

// EventMetadata contains additional context
type EventMetadata struct {
	Source       string            `json:"source,omitempty"`
	ReferenceURL string            `json:"reference_url,omitempty"`
	Tags         []string          `json:"tags,omitempty"`
	CustomFields map[string]string `json:"custom_fields,omitempty"`
}

// SpecEvent represents spec generation/update from Assure Code
type SpecEvent struct {
	BaseEvent
	WorkspaceID   string     `json:"workspace_id"`
	SpecType      string     `json:"spec_type"` // e.g., "data-retention", "access-control"
	Framework     Framework  `json:"framework"`
	SpecContent   string     `json:"spec_content,omitempty"`
	GitHubPR      *GitHubPR  `json:"github_pr,omitempty"`
	ValidationStatus string  `json:"validation_status,omitempty"`
}

// GitHubPR contains PR details
type GitHubPR struct {
	Repository string `json:"repository"`
	PRNumber   int    `json:"pr_number,omitempty"`
	PRURL      string `json:"pr_url,omitempty"`
	Status     string `json:"status"` // "created", "merged", "closed"
}

// ScanEvent represents audit results from Assure Scan
type ScanEvent struct {
	BaseEvent
	WorkspaceID     string           `json:"workspace_id"`
	ScanType        string           `json:"scan_type"` // "full", "incremental", "targeted"
	Framework       Framework        `json:"framework"`
	Findings        []Finding        `json:"findings,omitempty"`
	ComplianceScore float64          `json:"compliance_score,omitempty"`
	Status          string           `json:"status"` // "started", "in_progress", "completed", "failed"
}

// Finding represents a compliance violation or issue
type Finding struct {
	FindingID   string    `json:"finding_id"`
	Severity    Severity  `json:"severity"`
	Category    string    `json:"category"`
	Description string    `json:"description"`
	Location    string    `json:"location,omitempty"`
	Remediation string    `json:"remediation,omitempty"`
	AssetType   AssetType `json:"asset_type,omitempty"`
}

// ReviewEvent represents document analysis from Assure Review
type ReviewEvent struct {
	BaseEvent
	DocumentID      string           `json:"document_id"`
	DocumentType    DocumentType     `json:"document_type"`
	Framework       Framework        `json:"framework"`
	ComplianceGaps  []ComplianceGap  `json:"compliance_gaps,omitempty"`
	RiskScore       float64          `json:"risk_score,omitempty"`
	Status          string           `json:"status"` // "uploaded", "analyzing", "completed"
}

// DocumentType categorizes uploaded documents
type DocumentType string

const (
	DocumentContract       DocumentType = "CONTRACT"
	DocumentPolicy         DocumentType = "POLICY"
	DocumentAdvertisement  DocumentType = "ADVERTISEMENT"
	DocumentTermsOfService DocumentType = "TERMS_OF_SERVICE"
	DocumentPrivacyPolicy  DocumentType = "PRIVACY_POLICY"
	DocumentNDA            DocumentType = "NDA"
)

// ComplianceGap represents issues found in documents
type ComplianceGap struct {
	GapID          string    `json:"gap_id"`
	Severity       Severity  `json:"severity"`
	Clause         string    `json:"clause"`
	Issue          string    `json:"issue"`
	Recommendation string    `json:"recommendation,omitempty"`
	LawReference   string    `json:"law_reference,omitempty"`
}

// WorkflowEvent represents orchestration events
type WorkflowEvent struct {
	BaseEvent
	WorkflowID   string                 `json:"workflow_id"`
	WorkflowType string                 `json:"workflow_type"` // "regulatory_update", "document_review", etc.
	Steps        []WorkflowStep         `json:"steps"`
	Status       string                 `json:"status"`
	Result       map[string]interface{} `json:"result,omitempty"`
}

// WorkflowStep tracks individual workflow stages
type WorkflowStep struct {
	StepID     string    `json:"step_id"`
	Platform   Platform  `json:"platform"`
	Action     string    `json:"action"`
	Status     string    `json:"status"` // "pending", "in_progress", "completed", "failed"
	StartTime  time.Time `json:"start_time,omitempty"`
	EndTime    time.Time `json:"end_time,omitempty"`
	ErrorMsg   string    `json:"error_msg,omitempty"`
}

// ValidationEvent represents validation status updates
type ValidationEvent struct {
	BaseEvent
	TargetEventID  string                 `json:"target_event_id"` // Event being validated
	ValidationType string                 `json:"validation_type"` // "consensus", "partial", "conflict"
	Validators     []string               `json:"validators"`      // Platforms that validated
	Result         string                 `json:"result"`          // "approved", "rejected", "conflict"
	Details        map[string]interface{} `json:"details,omitempty"`
}

// ToJSON serializes event to JSON
func (e *BaseEvent) ToJSON() ([]byte, error) {
	return json.Marshal(e)
}

// FromJSON deserializes event from JSON
func FromJSON(data []byte) (*BaseEvent, error) {
	var event BaseEvent
	err := json.Unmarshal(data, &event)
	return &event, err
}

// GetEventTypeInterface returns the appropriate struct for an event type
func GetEventTypeInterface(eventType EventType) interface{} {
	switch eventType {
	case EventRegulatoryUpdate, EventLawFetched:
		return &RegulatoryEvent{}
	case EventSpecGenerated, EventSpecUpdated, EventSpecRequested:
		return &SpecEvent{}
	case EventAuditStarted, EventAuditCompleted, EventViolationFound, EventScanRequested:
		return &ScanEvent{}
	case EventDocumentUploaded, EventComplianceCheck, EventGapIdentified, EventReviewRequested:
		return &ReviewEvent{}
	case EventWorkflowStarted, EventWorkflowComplete:
		return &WorkflowEvent{}
	case EventValidationStatus:
		return &ValidationEvent{}
	default:
		return &BaseEvent{}
	}
}
