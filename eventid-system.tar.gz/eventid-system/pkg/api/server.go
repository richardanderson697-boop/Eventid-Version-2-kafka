package api

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/assure-compliance/eventid/pkg/auth"
	"github.com/assure-compliance/eventid/pkg/producer"
	"github.com/assure-compliance/eventid/pkg/schema"
	"github.com/assure-compliance/eventid/pkg/storage"
	"github.com/gorilla/mux"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/rs/cors"
)

// Server handles API requests
type Server struct {
	router      *mux.Router
	authService *auth.AuthService
	producer    *producer.EventProducer
	eventStore  *storage.EventStore
	rateLimiter *RateLimiter
	metrics     *Metrics
}

// Metrics for Prometheus
type Metrics struct {
	requestsTotal   *prometheus.CounterVec
	eventsPublished *prometheus.CounterVec
	requestDuration *prometheus.HistogramVec
}

// NewServer creates a new API server
func NewServer(authService *auth.AuthService, prod *producer.EventProducer, store *storage.EventStore) *Server {
	metrics := &Metrics{
		requestsTotal: promauto.NewCounterVec(
			prometheus.CounterOpts{
				Name: "api_requests_total",
				Help: "Total number of API requests",
			},
			[]string{"method", "endpoint", "status"},
		),
		eventsPublished: promauto.NewCounterVec(
			prometheus.CounterOpts{
				Name: "events_published_total",
				Help: "Total number of events published to Kafka",
			},
			[]string{"platform", "event_type"},
		),
		requestDuration: promauto.NewHistogramVec(
			prometheus.HistogramOpts{
				Name:    "api_request_duration_seconds",
				Help:    "API request duration in seconds",
				Buckets: prometheus.DefBuckets,
			},
			[]string{"method", "endpoint"},
		),
	}

	server := &Server{
		router:      mux.NewRouter(),
		authService: authService,
		producer:    prod,
		eventStore:  store,
		rateLimiter: NewRateLimiter(60, time.Minute), // 60 requests per minute
		metrics:     metrics,
	}

	server.routes()
	return server
}

// routes sets up API endpoints
func (s *Server) routes() {
	// Health check
	s.router.HandleFunc("/health", s.handleHealth()).Methods("GET")

	// Metrics
	s.router.Handle("/metrics", promhttp.Handler()).Methods("GET")

	// Event endpoints (require auth)
	api := s.router.PathPrefix("/v1").Subrouter()
	api.Use(s.authMiddleware)
	api.Use(s.rateLimitMiddleware)
	api.Use(s.metricsMiddleware)

	api.HandleFunc("/events", s.handlePublishEvent()).Methods("POST")
	api.HandleFunc("/events", s.handleQueryEvents()).Methods("GET")
	api.HandleFunc("/events/{event_id}", s.handleGetEvent()).Methods("GET")
}

// handleHealth returns service health
func (s *Server) handleHealth() http.HandlerFunc {
	type healthResponse struct {
		Status    string    `json:"status"`
		Timestamp time.Time `json:"timestamp"`
	}

	return func(w http.ResponseWriter, r *http.Request) {
		response := healthResponse{
			Status:    "healthy",
			Timestamp: time.Now(),
		}
		respondJSON(w, http.StatusOK, response)
	}
}

// handlePublishEvent publishes events from platforms
func (s *Server) handlePublishEvent() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Get client from context (set by authMiddleware)
		client := r.Context().Value("client").(*auth.Client)

		// Parse request body
		var rawEvent map[string]interface{}
		if err := json.NewDecoder(r.Body).Decode(&rawEvent); err != nil {
			respondError(w, http.StatusBadRequest, "Invalid JSON", err)
			return
		}

		// Determine event type
		eventTypeStr, ok := rawEvent["event_type"].(string)
		if !ok {
			respondError(w, http.StatusBadRequest, "Missing event_type field", nil)
			return
		}

		eventType := schema.EventType(eventTypeStr)

		// Generate event ID if not provided
		if _, hasID := rawEvent["event_id"]; !hasID {
			eventID, err := schema.GenerateUUIDv7()
			if err != nil {
				respondError(w, http.StatusInternalServerError, "Failed to generate event ID", err)
				return
			}
			rawEvent["event_id"] = eventID
		}

		// Set platform and timestamp
		rawEvent["platform"] = client.Platform
		rawEvent["timestamp"] = time.Now()
		rawEvent["event_version"] = schema.EventVersion

		// Marshal back to JSON for validation
		eventData, err := json.Marshal(rawEvent)
		if err != nil {
			respondError(w, http.StatusInternalServerError, "Failed to marshal event", err)
			return
		}

		// Unmarshal to proper event type for validation
		eventInterface := schema.GetEventTypeInterface(eventType)
		if err := json.Unmarshal(eventData, eventInterface); err != nil {
			respondError(w, http.StatusBadRequest, "Invalid event schema", err)
			return
		}

		// Publish to Kafka
		if err := s.producer.PublishEvent(eventInterface); err != nil {
			respondError(w, http.StatusInternalServerError, "Failed to publish event", err)
			return
		}

		// Update metrics
		s.metrics.eventsPublished.WithLabelValues(client.Platform, eventTypeStr).Inc()

		// Return success response
		var baseEvent schema.BaseEvent
		json.Unmarshal(eventData, &baseEvent)

		response := map[string]interface{}{
			"event_id":  baseEvent.EventID,
			"status":    "accepted",
			"timestamp": baseEvent.Timestamp,
		}

		respondJSON(w, http.StatusCreated, response)
	}
}

// handleGetEvent retrieves a specific event
func (s *Server) handleGetEvent() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		eventID := vars["event_id"]

		event, err := s.eventStore.GetEventByID(eventID)
		if err != nil {
			if strings.Contains(err.Error(), "not found") {
				respondError(w, http.StatusNotFound, "Event not found", err)
			} else {
				respondError(w, http.StatusInternalServerError, "Failed to retrieve event", err)
			}
			return
		}

		respondJSON(w, http.StatusOK, event)
	}
}

// handleQueryEvents searches for events
func (s *Server) handleQueryEvents() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		query := r.URL.Query()

		filters := storage.EventFilters{
			Platform:      schema.Platform(query.Get("platform")),
			EventType:     schema.EventType(query.Get("event_type")),
			CorrelationID: query.Get("correlation_id"),
			Limit:         50,  // Default limit
			Offset:        0,
		}

		// Parse time filters
		if startTime := query.Get("from"); startTime != "" {
			if t, err := time.Parse(time.RFC3339, startTime); err == nil {
				filters.StartTime = t
			}
		}
		if endTime := query.Get("to"); endTime != "" {
			if t, err := time.Parse(time.RFC3339, endTime); err == nil {
				filters.EndTime = t
			}
		}

		// Parse pagination
		if limit := query.Get("limit"); limit != "" {
			fmt.Sscanf(limit, "%d", &filters.Limit)
			if filters.Limit > 1000 {
				filters.Limit = 1000 // Max limit
			}
		}
		if offset := query.Get("offset"); offset != "" {
			fmt.Sscanf(offset, "%d", &filters.Offset)
		}

		events, err := s.eventStore.QueryEvents(filters)
		if err != nil {
			respondError(w, http.StatusInternalServerError, "Failed to query events", err)
			return
		}

		response := map[string]interface{}{
			"events": events,
			"pagination": map[string]interface{}{
				"limit":  filters.Limit,
				"offset": filters.Offset,
			},
		}

		respondJSON(w, http.StatusOK, response)
	}
}

// authMiddleware validates JWT tokens
func (s *Server) authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			respondError(w, http.StatusUnauthorized, "Missing Authorization header", nil)
			return
		}

		// Extract token
		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			respondError(w, http.StatusUnauthorized, "Invalid Authorization header format", nil)
			return
		}

		tokenString := parts[1]

		// Validate token
		claims, err := s.authService.ValidateToken(tokenString)
		if err != nil {
			respondError(w, http.StatusUnauthorized, "Invalid token", err)
			return
		}

		// Get client
		client, err := s.authService.GetClient(claims.ClientID)
		if err != nil {
			respondError(w, http.StatusUnauthorized, "Invalid client", err)
			return
		}

		// Add client to context
		ctx := r.Context()
		ctx = r.WithContext(ctx)
		r = r.WithContext(ctx)
		r = r.WithContext(r.Context())
		
		// Store client in request context (simplified - in production use context.WithValue)
		r.Header.Set("X-Client-ID", client.ClientID)
		r.Header.Set("X-Platform", client.Platform)

		next.ServeHTTP(w, r)
	})
}

// rateLimitMiddleware enforces rate limits
func (s *Server) rateLimitMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		clientID := r.Header.Get("X-Client-ID")
		
		if !s.rateLimiter.Allow(clientID) {
			respondError(w, http.StatusTooManyRequests, "Rate limit exceeded", nil)
			return
		}

		next.ServeHTTP(w, r)
	})
}

// metricsMiddleware tracks request metrics
func (s *Server) metricsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()

		// Wrap response writer to capture status code
		wrapped := &responseWriter{ResponseWriter: w, statusCode: http.StatusOK}

		next.ServeHTTP(wrapped, r)

		duration := time.Since(start).Seconds()
		endpoint := r.URL.Path

		s.metrics.requestsTotal.WithLabelValues(
			r.Method,
			endpoint,
			fmt.Sprintf("%d", wrapped.statusCode),
		).Inc()

		s.metrics.requestDuration.WithLabelValues(
			r.Method,
			endpoint,
		).Observe(duration)
	})
}

// Start starts the HTTP server
func (s *Server) Start(addr string) error {
	// Add CORS
	handler := cors.New(cors.Options{
		AllowedOrigins:   []string{"*"},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Authorization", "Content-Type"},
		AllowCredentials: true,
	}).Handler(s.router)

	log.Printf("API server starting on %s\n", addr)
	return http.ListenAndServe(addr, handler)
}

// Helper functions
func respondJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func respondError(w http.ResponseWriter, status int, message string, err error) {
	response := map[string]interface{}{
		"error":   message,
		"status":  status,
	}
	if err != nil {
		log.Printf("Error: %s - %v\n", message, err)
	}
	respondJSON(w, status, response)
}

// responseWriter wraps http.ResponseWriter to capture status code
type responseWriter struct {
	http.ResponseWriter
	statusCode int
}

func (rw *responseWriter) WriteHeader(code int) {
	rw.statusCode = code
	rw.ResponseWriter.WriteHeader(code)
}
