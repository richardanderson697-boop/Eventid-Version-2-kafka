package storage

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"time"

	"github.com/assure-compliance/eventid/pkg/schema"
	_ "github.com/lib/pq"
)

// EventStore handles persistent storage of events
type EventStore struct {
	db *sql.DB
}

// Config holds database configuration
type Config struct {
	Host     string
	Port     int
	User     string
	Password string
	Database string
	SSLMode  string
}

// NewEventStore creates a new event store
func NewEventStore(cfg Config) (*EventStore, error) {
	connStr := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
		cfg.Host, cfg.Port, cfg.User, cfg.Password, cfg.Database, cfg.SSLMode)

	db, err := sql.Open("postgres", connStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	// Test connection
	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	// Set connection pool settings
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(5 * time.Minute)

	return &EventStore{db: db}, nil
}

// StoreEvent persists an event to the database
func (s *EventStore) StoreEvent(event interface{}) error {
	// Serialize event to JSON
	eventData, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal event: %w", err)
	}

	// Extract base event fields
	var baseEvent schema.BaseEvent
	if err := json.Unmarshal(eventData, &baseEvent); err != nil {
		return fmt.Errorf("failed to extract base event: %w", err)
	}

	query := `
		INSERT INTO events (
			event_id, event_version, event_type, platform, 
			timestamp, correlation_id, user_id, event_data
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`

	_, err = s.db.Exec(query,
		baseEvent.EventID,
		baseEvent.EventVersion,
		baseEvent.EventType,
		baseEvent.Platform,
		baseEvent.Timestamp,
		sql.NullString{String: baseEvent.CorrelationID, Valid: baseEvent.CorrelationID != ""},
		sql.NullString{String: baseEvent.UserID, Valid: baseEvent.UserID != ""},
		eventData,
	)

	if err != nil {
		return fmt.Errorf("failed to insert event: %w", err)
	}

	return nil
}

// GetEventByID retrieves an event by its ID
func (s *EventStore) GetEventByID(eventID string) (map[string]interface{}, error) {
	query := `
		SELECT event_data 
		FROM events 
		WHERE event_id = $1
	`

	var eventData []byte
	err := s.db.QueryRow(query, eventID).Scan(&eventData)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("event not found: %s", eventID)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to query event: %w", err)
	}

	var result map[string]interface{}
	if err := json.Unmarshal(eventData, &result); err != nil {
		return nil, fmt.Errorf("failed to unmarshal event data: %w", err)
	}

	return result, nil
}

// QueryEvents retrieves events based on filters
func (s *EventStore) QueryEvents(filters EventFilters) ([]map[string]interface{}, error) {
	query := `
		SELECT event_data 
		FROM events 
		WHERE 1=1
	`
	args := []interface{}{}
	argCount := 1

	if filters.Platform != "" {
		query += fmt.Sprintf(" AND platform = $%d", argCount)
		args = append(args, filters.Platform)
		argCount++
	}

	if filters.EventType != "" {
		query += fmt.Sprintf(" AND event_type = $%d", argCount)
		args = append(args, filters.EventType)
		argCount++
	}

	if !filters.StartTime.IsZero() {
		query += fmt.Sprintf(" AND timestamp >= $%d", argCount)
		args = append(args, filters.StartTime)
		argCount++
	}

	if !filters.EndTime.IsZero() {
		query += fmt.Sprintf(" AND timestamp <= $%d", argCount)
		args = append(args, filters.EndTime)
		argCount++
	}

	if filters.CorrelationID != "" {
		query += fmt.Sprintf(" AND correlation_id = $%d", argCount)
		args = append(args, filters.CorrelationID)
		argCount++
	}

	// Add ordering and pagination
	query += " ORDER BY timestamp DESC"
	
	if filters.Limit > 0 {
		query += fmt.Sprintf(" LIMIT $%d", argCount)
		args = append(args, filters.Limit)
		argCount++
	}

	if filters.Offset > 0 {
		query += fmt.Sprintf(" OFFSET $%d", argCount)
		args = append(args, filters.Offset)
	}

	rows, err := s.db.Query(query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to query events: %w", err)
	}
	defer rows.Close()

	var results []map[string]interface{}
	for rows.Next() {
		var eventData []byte
		if err := rows.Scan(&eventData); err != nil {
			return nil, fmt.Errorf("failed to scan row: %w", err)
		}

		var event map[string]interface{}
		if err := json.Unmarshal(eventData, &event); err != nil {
			return nil, fmt.Errorf("failed to unmarshal event: %w", err)
		}

		results = append(results, event)
	}

	return results, nil
}

// EventFilters defines query parameters
type EventFilters struct {
	Platform      schema.Platform
	EventType     schema.EventType
	StartTime     time.Time
	EndTime       time.Time
	CorrelationID string
	Limit         int
	Offset        int
}

// Close closes the database connection
func (s *EventStore) Close() error {
	return s.db.Close()
}
