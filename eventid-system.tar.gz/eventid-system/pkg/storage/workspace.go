package storage

import (
	"database/sql"
	"encoding/json"
	"fmt"

	"github.com/assure-compliance/eventid/pkg/schema"
)

// WorkspaceStore manages workspace configurations
type WorkspaceStore struct {
	db *sql.DB
}

// NewWorkspaceStore creates a workspace store
func NewWorkspaceStore(cfg Config) (*WorkspaceStore, error) {
	connStr := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
		cfg.Host, cfg.Port, cfg.User, cfg.Password, cfg.Database, cfg.SSLMode)

	db, err := sql.Open("postgres", connStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)

	return &WorkspaceStore{db: db}, nil
}

// Workspace represents a compliance workspace configuration
type Workspace struct {
	WorkspaceID  string              `json:"workspace_id"`
	UserID       string              `json:"user_id"`
	Name         string              `json:"name"`
	Frameworks   []schema.Framework  `json:"frameworks"`
	Jurisdiction schema.Region       `json:"jurisdiction"`
	Modules      []schema.AssetType  `json:"modules"`
	GitHubRepo   string              `json:"github_repo,omitempty"`
	Active       bool                `json:"active"`
	Settings     map[string]string   `json:"settings,omitempty"`
}

// CreateWorkspace creates a new workspace
func (s *WorkspaceStore) CreateWorkspace(workspace *Workspace) error {
	frameworks, _ := json.Marshal(workspace.Frameworks)
	modules, _ := json.Marshal(workspace.Modules)
	settings, _ := json.Marshal(workspace.Settings)

	query := `
		INSERT INTO workspaces (
			workspace_id, user_id, name, frameworks, jurisdiction, 
			modules, github_repo, active, settings
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
	`

	_, err := s.db.Exec(query,
		workspace.WorkspaceID,
		workspace.UserID,
		workspace.Name,
		frameworks,
		workspace.Jurisdiction,
		modules,
		sql.NullString{String: workspace.GitHubRepo, Valid: workspace.GitHubRepo != ""},
		workspace.Active,
		settings,
	)

	if err != nil {
		return fmt.Errorf("failed to create workspace: %w", err)
	}

	return nil
}

// GetWorkspace retrieves a workspace by ID
func (s *WorkspaceStore) GetWorkspace(workspaceID string) (*Workspace, error) {
	query := `
		SELECT workspace_id, user_id, name, frameworks, jurisdiction, 
		       modules, github_repo, active, settings
		FROM workspaces
		WHERE workspace_id = $1
	`

	var workspace Workspace
	var frameworks, modules, settings []byte
	var githubRepo sql.NullString

	err := s.db.QueryRow(query, workspaceID).Scan(
		&workspace.WorkspaceID,
		&workspace.UserID,
		&workspace.Name,
		&frameworks,
		&workspace.Jurisdiction,
		&modules,
		&githubRepo,
		&workspace.Active,
		&settings,
	)

	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("workspace not found: %s", workspaceID)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to query workspace: %w", err)
	}

	json.Unmarshal(frameworks, &workspace.Frameworks)
	json.Unmarshal(modules, &workspace.Modules)
	json.Unmarshal(settings, &workspace.Settings)
	workspace.GitHubRepo = githubRepo.String

	return &workspace, nil
}

// GetActiveWorkspaces retrieves all active workspaces
func (s *WorkspaceStore) GetActiveWorkspaces() ([]*Workspace, error) {
	query := `
		SELECT workspace_id, user_id, name, frameworks, jurisdiction, 
		       modules, github_repo, active, settings
		FROM workspaces
		WHERE active = true
	`

	rows, err := s.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("failed to query workspaces: %w", err)
	}
	defer rows.Close()

	var workspaces []*Workspace
	for rows.Next() {
		var workspace Workspace
		var frameworks, modules, settings []byte
		var githubRepo sql.NullString

		err := rows.Scan(
			&workspace.WorkspaceID,
			&workspace.UserID,
			&workspace.Name,
			&frameworks,
			&workspace.Jurisdiction,
			&modules,
			&githubRepo,
			&workspace.Active,
			&settings,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan workspace: %w", err)
		}

		json.Unmarshal(frameworks, &workspace.Frameworks)
		json.Unmarshal(modules, &workspace.Modules)
		json.Unmarshal(settings, &workspace.Settings)
		workspace.GitHubRepo = githubRepo.String

		workspaces = append(workspaces, &workspace)
	}

	return workspaces, nil
}

// MatchWorkspaces finds workspaces that match a regulatory event
func (s *WorkspaceStore) MatchWorkspaces(event *schema.RegulatoryEvent) ([]*Workspace, error) {
	// Get all active workspaces
	workspaces, err := s.GetActiveWorkspaces()
	if err != nil {
		return nil, err
	}

	var matched []*Workspace
	for _, workspace := range workspaces {
		if s.workspaceMatches(workspace, event) {
			matched = append(matched, workspace)
		}
	}

	return matched, nil
}

// workspaceMatches checks if a workspace matches an event
func (s *WorkspaceStore) workspaceMatches(workspace *Workspace, event *schema.RegulatoryEvent) bool {
	// Check framework match
	frameworkMatch := false
	for _, framework := range workspace.Frameworks {
		if framework == event.Jurisdiction.Framework {
			frameworkMatch = true
			break
		}
	}
	if !frameworkMatch {
		return false
	}

	// Check jurisdiction match (GLOBAL matches all)
	if workspace.Jurisdiction != schema.RegionGlobal && 
	   workspace.Jurisdiction != event.Jurisdiction.Region {
		return false
	}

	// Check if any affected assets match workspace modules
	for _, asset := range event.AffectedAssets {
		for _, module := range workspace.Modules {
			if asset.AssetType == module {
				return true
			}
		}
	}

	return false
}

// UpdateWorkspace updates workspace configuration
func (s *WorkspaceStore) UpdateWorkspace(workspace *Workspace) error {
	frameworks, _ := json.Marshal(workspace.Frameworks)
	modules, _ := json.Marshal(workspace.Modules)
	settings, _ := json.Marshal(workspace.Settings)

	query := `
		UPDATE workspaces 
		SET name = $1, frameworks = $2, jurisdiction = $3, 
		    modules = $4, github_repo = $5, active = $6, settings = $7
		WHERE workspace_id = $8
	`

	result, err := s.db.Exec(query,
		workspace.Name,
		frameworks,
		workspace.Jurisdiction,
		modules,
		sql.NullString{String: workspace.GitHubRepo, Valid: workspace.GitHubRepo != ""},
		workspace.Active,
		settings,
		workspace.WorkspaceID,
	)

	if err != nil {
		return fmt.Errorf("failed to update workspace: %w", err)
	}

	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("workspace not found: %s", workspace.WorkspaceID)
	}

	return nil
}

// Close closes the database connection
func (s *WorkspaceStore) Close() error {
	return s.db.Close()
}
