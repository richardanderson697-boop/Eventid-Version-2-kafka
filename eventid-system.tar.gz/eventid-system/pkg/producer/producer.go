package producer

import (
	"encoding/json"
	"fmt"
	"log"

	"github.com/assure-compliance/eventid/pkg/schema"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
)

// EventProducer handles publishing events to Kafka
type EventProducer struct {
	producer *kafka.Producer
	topic    string
}

// Config holds producer configuration
type Config struct {
	BootstrapServers string
	Topic            string
}

// NewEventProducer creates a new Kafka producer
func NewEventProducer(cfg Config) (*EventProducer, error) {
	config := &kafka.ConfigMap{
		"bootstrap.servers": cfg.BootstrapServers,
		"acks":              "all", // Wait for all replicas
		"retries":           10,
		"max.in.flight.requests.per.connection": 5,
		"enable.idempotence":                    true,
		"compression.type":                      "snappy",
	}

	producer, err := kafka.NewProducer(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create producer: %w", err)
	}

	// Start delivery report handler
	go func() {
		for e := range producer.Events() {
			switch ev := e.(type) {
			case *kafka.Message:
				if ev.TopicPartition.Error != nil {
					log.Printf("Delivery failed: %v\n", ev.TopicPartition.Error)
				} else {
					log.Printf("Delivered message to %v\n", ev.TopicPartition)
				}
			}
		}
	}()

	return &EventProducer{
		producer: producer,
		topic:    cfg.Topic,
	}, nil
}

// PublishEvent sends an event to Kafka
func (p *EventProducer) PublishEvent(event interface{}) error {
	// Serialize event to JSON
	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal event: %w", err)
	}

	// Extract event ID for use as key (ensures ordering per event ID)
	var baseEvent schema.BaseEvent
	if err := json.Unmarshal(data, &baseEvent); err != nil {
		return fmt.Errorf("failed to extract base event: %w", err)
	}

	// Produce message
	err = p.producer.Produce(&kafka.Message{
		TopicPartition: kafka.TopicPartition{
			Topic:     &p.topic,
			Partition: kafka.PartitionAny,
		},
		Key:   []byte(baseEvent.EventID),
		Value: data,
		Headers: []kafka.Header{
			{Key: "event_type", Value: []byte(baseEvent.EventType)},
			{Key: "platform", Value: []byte(baseEvent.Platform)},
		},
	}, nil)

	if err != nil {
		return fmt.Errorf("failed to produce message: %w", err)
	}

	return nil
}

// PublishRegulatoryEvent publishes a regulatory event
func (p *EventProducer) PublishRegulatoryEvent(event *schema.RegulatoryEvent) error {
	return p.PublishEvent(event)
}

// PublishSpecEvent publishes a spec generation event
func (p *EventProducer) PublishSpecEvent(event *schema.SpecEvent) error {
	return p.PublishEvent(event)
}

// PublishScanEvent publishes an audit/scan event
func (p *EventProducer) PublishScanEvent(event *schema.ScanEvent) error {
	return p.PublishEvent(event)
}

// PublishReviewEvent publishes a document review event
func (p *EventProducer) PublishReviewEvent(event *schema.ReviewEvent) error {
	return p.PublishEvent(event)
}

// PublishWorkflowEvent publishes a workflow orchestration event
func (p *EventProducer) PublishWorkflowEvent(event *schema.WorkflowEvent) error {
	return p.PublishEvent(event)
}

// Flush waits for all messages to be delivered
func (p *EventProducer) Flush(timeoutMs int) {
	p.producer.Flush(timeoutMs)
}

// Close shuts down the producer
func (p *EventProducer) Close() {
	p.producer.Close()
}
