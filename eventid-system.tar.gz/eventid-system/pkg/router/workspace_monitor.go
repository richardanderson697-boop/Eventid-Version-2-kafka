package router

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/assure-compliance/eventid/pkg/producer"
	"github.com/assure-compliance/eventid/pkg/schema"
	"github.com/assure-compliance/eventid/pkg/storage"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

// WorkspaceMonitor orchestrates events across platforms
type WorkspaceMonitor struct {
	workspaceStore  *storage.WorkspaceStore
	producer        *producer.EventProducer
	githubToken     string
	assureCodeURL   string
	assureCodeKey   string
	minSeverity     schema.Severity
	metrics         *MonitorMetrics
}

// MonitorMetrics tracks orchestration metrics
type MonitorMetrics struct {
	eventsProcessed   prometheus.Counter
	workspacesMatched *prometheus.CounterVec
	specsRegenerated  prometheus.Counter
	githubPRsCreated  prometheus.Counter
	errors            *prometheus.CounterVec
}

// Config holds monitor configuration
type Config struct {
	WorkspaceStore *storage.WorkspaceStore
	Producer       *producer.EventProducer
	GitHubToken    string
	AssureCodeURL  string
	AssureCodeKey  string
	MinSeverity    string
}

// NewWorkspaceMonitor creates a new workspace monitor
func NewWorkspaceMonitor(cfg Config) *WorkspaceMonitor {
	minSeverity := schema.SeverityHigh
	if cfg.MinSeverity != "" {
		minSeverity = schema.Severity(cfg.MinSeverity)
	}

	metrics := &MonitorMetrics{
		eventsProcessed: promauto.NewCounter(prometheus.CounterOpts{
			Name: "workspace_events_processed_total",
			Help: "Total events processed by workspace monitor",
		}),
		workspacesMatched: promauto.NewCounterVec(
			prometheus.CounterOpts{
				Name: "workspaces_matched_total",
				Help: "Total workspaces matched per event",
			},
			[]string{"event_type", "framework"},
		),
		specsRegenerated: promauto.NewCounter(prometheus.CounterOpts{
			Name: "specs_regenerated_total",
			Help: "Total specs regenerated via ASSURE-CODE",
		}),
		githubPRsCreated: promauto.NewCounter(prometheus.CounterOpts{
			Name: "github_prs_created_total",
			Help: "Total GitHub PRs created",
		}),
		errors: promauto.NewCounterVec(
			prometheus.CounterOpts{
				Name: "workspace_monitor_errors_total",
				Help: "Total errors in workspace monitor",
			},
			[]string{"error_type"},
		),
	}

	return &WorkspaceMonitor{
		workspaceStore: cfg.WorkspaceStore,
		producer:       cfg.Producer,
		githubToken:    cfg.GitHubToken,
		assureCodeURL:  cfg.AssureCodeURL,
		assureCodeKey:  cfg.AssureCodeKey,
		minSeverity:    minSeverity,
		metrics:        metrics,
	}
}

// HandleRegulatoryEvent processes regulatory updates
func (m *WorkspaceMonitor) HandleRegulatoryEvent(event interface{}) error {
	regEvent, ok := event.(*schema.RegulatoryEvent)
	if !ok {
		return fmt.Errorf("invalid event type")
	}

	m.metrics.eventsProcessed.Inc()

	log.Printf("Processing regulatory event: %s (Framework: %s, Severity: %s)\n",
		regEvent.EventID, regEvent.Jurisdiction.Framework, regEvent.RiskContext.ChangeSeverity)

	// Check if severity meets threshold
	if !m.meetsSeverityThreshold(regEvent.RiskContext.ChangeSeverity) {
		log.Printf("Event %s below severity threshold, skipping automation\n", regEvent.EventID)
		return nil
	}

	// Find matching workspaces
	workspaces, err := m.workspaceStore.MatchWorkspaces(regEvent)
	if err != nil {
		m.metrics.errors.WithLabelValues("workspace_match").Inc()
		return fmt.Errorf("failed to match workspaces: %w", err)
	}

	log.Printf("Found %d matching workspaces for event %s\n", len(workspaces), regEvent.EventID)

	if len(workspaces) == 0 {
		return nil
	}

	m.metrics.workspacesMatched.WithLabelValues(
		string(regEvent.EventType),
		string(regEvent.Jurisdiction.Framework),
	).Add(float64(len(workspaces)))

	// Process each workspace
	for _, workspace := range workspaces {
		if err := m.processWorkspace(workspace, regEvent); err != nil {
			log.Printf("Failed to process workspace %s: %v\n", workspace.WorkspaceID, err)
			m.metrics.errors.WithLabelValues("workspace_processing").Inc()
			continue
		}
	}

	return nil
}

// processWorkspace triggers spec regeneration and PR creation
func (m *WorkspaceMonitor) processWorkspace(workspace *storage.Workspace, event *schema.RegulatoryEvent) error {
	log.Printf("Processing workspace: %s for event: %s\n", workspace.WorkspaceID, event.EventID)

	// Create workflow event
	workflowID, _ := schema.GenerateUUIDv7()
	workflow := &schema.WorkflowEvent{
		BaseEvent: schema.BaseEvent{
			EventID:       workflowID,
			EventVersion:  schema.EventVersion,
			EventType:     schema.EventWorkflowStarted,
			Platform:      schema.PlatformEventID,
			Timestamp:     time.Now(),
			CorrelationID: event.EventID,
		},
		WorkflowID:   workflowID,
		WorkflowType: "regulatory_update",
		Status:       "in_progress",
		Steps: []schema.WorkflowStep{
			{
				StepID:    "spec_regen",
				Platform:  schema.PlatformCode,
				Action:    "regenerate_spec",
				Status:    "pending",
				StartTime: time.Now(),
			},
			{
				StepID:   "github_pr",
				Platform: schema.PlatformEventID,
				Action:   "create_pr",
				Status:   "pending",
			},
		},
	}

	// Publish workflow start event
	m.producer.PublishWorkflowEvent(workflow)

	// 1. Request spec regeneration from Assure Code
	specEvent, err := m.regenerateSpec(workspace, event)
	if err != nil {
		log.Printf("Failed to regenerate spec: %v\n", err)
		m.metrics.errors.WithLabelValues("spec_regen").Inc()
		
		// Update workflow status
		workflow.Status = "failed"
		workflow.Steps[0].Status = "failed"
		workflow.Steps[0].ErrorMsg = err.Error()
		workflow.Steps[0].EndTime = time.Now()
		m.producer.PublishWorkflowEvent(workflow)
		
		return err
	}

	m.metrics.specsRegenerated.Inc()
	workflow.Steps[0].Status = "completed"
	workflow.Steps[0].EndTime = time.Now()

	// 2. Create GitHub PR
	if workspace.GitHubRepo != "" {
		pr, err := m.createGitHubPR(workspace, event, specEvent)
		if err != nil {
			log.Printf("Failed to create GitHub PR: %v\n", err)
			m.metrics.errors.WithLabelValues("github_pr").Inc()
			
			workflow.Steps[1].Status = "failed"
			workflow.Steps[1].ErrorMsg = err.Error()
		} else {
			m.metrics.githubPRsCreated.Inc()
			workflow.Steps[1].Status = "completed"
			specEvent.GitHubPR = pr
		}
		workflow.Steps[1].EndTime = time.Now()
	}

	// Publish spec event
	m.producer.PublishSpecEvent(specEvent)

	// Complete workflow
	workflow.Status = "completed"
	workflow.Result = map[string]interface{}{
		"workspace_id": workspace.WorkspaceID,
		"spec_event_id": specEvent.EventID,
	}
	m.producer.PublishWorkflowEvent(workflow)

	// 3. Trigger validation scan (request Assure Scan to validate)
	m.requestValidationScan(workspace, specEvent)

	return nil
}

// regenerateSpec calls Assure Code API to regenerate specifications
func (m *WorkspaceMonitor) regenerateSpec(workspace *storage.Workspace, event *schema.RegulatoryEvent) (*schema.SpecEvent, error) {
	// Prepare request for Assure Code
	request := map[string]interface{}{
		"workspace_id": workspace.WorkspaceID,
		"framework":    event.Jurisdiction.Framework,
		"regulation":   event.Metadata.Source,
		"severity":     event.RiskContext.ChangeSeverity,
		"assets":       event.AffectedAssets,
	}

	reqBody, _ := json.Marshal(request)

	// Call Assure Code API
	req, err := http.NewRequest("POST", m.assureCodeURL+"/api/regenerate-spec", bytes.NewBuffer(reqBody))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+m.assureCodeKey)

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("API request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("API returned status %d", resp.StatusCode)
	}

	// Parse response
	var result struct {
		SpecID      string `json:"spec_id"`
		SpecContent string `json:"spec_content"`
		SpecType    string `json:"spec_type"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	// Create spec event
	eventID, _ := schema.GenerateUUIDv7()
	specEvent := &schema.SpecEvent{
		BaseEvent: schema.BaseEvent{
			EventID:       eventID,
			EventVersion:  schema.EventVersion,
			EventType:     schema.EventSpecGenerated,
			Platform:      schema.PlatformCode,
			Timestamp:     time.Now(),
			CorrelationID: event.EventID,
		},
		WorkspaceID:      workspace.WorkspaceID,
		SpecType:         result.SpecType,
		Framework:        event.Jurisdiction.Framework,
		SpecContent:      result.SpecContent,
		ValidationStatus: "pending",
	}

	return specEvent, nil
}

// createGitHubPR creates a pull request with updated specs
func (m *WorkspaceMonitor) createGitHubPR(workspace *storage.Workspace, regEvent *schema.RegulatoryEvent, specEvent *schema.SpecEvent) (*schema.GitHubPR, error) {
	// Parse repository (owner/repo format)
	// This is simplified - production would use GitHub API library
	
	prTitle := fmt.Sprintf("Update %s compliance specs - %s", regEvent.Jurisdiction.Framework, regEvent.EventID[:8])
	prBody := fmt.Sprintf(`## Regulatory Update

**Framework:** %s
**Severity:** %s
**Event ID:** %s

### Changes
%s

### Affected Assets
%s

This PR was automatically generated by EventID in response to regulatory changes.
`, 
		regEvent.Jurisdiction.Framework,
		regEvent.RiskContext.ChangeSeverity,
		regEvent.EventID,
		regEvent.Metadata.Source,
		formatAssets(regEvent.AffectedAssets),
	)

	// Create PR via GitHub API (simplified)
	prRequest := map[string]interface{}{
		"title": prTitle,
		"body":  prBody,
		"head":  "compliance-update-" + regEvent.EventID[:8],
		"base":  "main",
	}

	reqBody, _ := json.Marshal(prRequest)
	
	apiURL := fmt.Sprintf("https://api.github.com/repos/%s/pulls", workspace.GitHubRepo)
	req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(reqBody))
	if err != nil {
		return nil, fmt.Errorf("failed to create PR request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+m.githubToken)
	req.Header.Set("Accept", "application/vnd.github.v3+json")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("GitHub API request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return nil, fmt.Errorf("GitHub API returned status %d", resp.StatusCode)
	}

	// Parse response
	var prResult struct {
		Number  int    `json:"number"`
		HTMLURL string `json:"html_url"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&prResult); err != nil {
		return nil, fmt.Errorf("failed to decode GitHub response: %w", err)
	}

	return &schema.GitHubPR{
		Repository: workspace.GitHubRepo,
		PRNumber:   prResult.Number,
		PRURL:      prResult.HTMLURL,
		Status:     "created",
	}, nil
}

// requestValidationScan publishes a scan request event
func (m *WorkspaceMonitor) requestValidationScan(workspace *storage.Workspace, specEvent *schema.SpecEvent) {
	eventID, _ := schema.GenerateUUIDv7()
	scanEvent := &schema.ScanEvent{
		BaseEvent: schema.BaseEvent{
			EventID:       eventID,
			EventVersion:  schema.EventVersion,
			EventType:     schema.EventScanRequested,
			Platform:      schema.PlatformEventID,
			Timestamp:     time.Now(),
			CorrelationID: specEvent.CorrelationID,
		},
		WorkspaceID: workspace.WorkspaceID,
		ScanType:    "validation",
		Framework:   specEvent.Framework,
		Status:      "requested",
	}

	m.producer.PublishScanEvent(scanEvent)
}

// meetsSeverityThreshold checks if event severity meets minimum threshold
func (m *WorkspaceMonitor) meetsSeverityThreshold(severity schema.Severity) bool {
	severityLevels := map[schema.Severity]int{
		schema.SeverityLow:      1,
		schema.SeverityMedium:   2,
		schema.SeverityHigh:     3,
		schema.SeverityCritical: 4,
	}

	return severityLevels[severity] >= severityLevels[m.minSeverity]
}

// formatAssets formats affected assets for PR description
func formatAssets(assets []schema.AffectedAsset) string {
	var result string
	for _, asset := range assets {
		result += fmt.Sprintf("- %s: %s\n", asset.AssetType, asset.Description)
	}
	return result
}
