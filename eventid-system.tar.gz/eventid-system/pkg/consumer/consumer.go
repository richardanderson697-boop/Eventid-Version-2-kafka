package consumer

import (
	"encoding/json"
	"fmt"
	"log"

	"github.com/assure-compliance/eventid/pkg/schema"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
)

// EventHandler is called for each consumed event
type EventHandler func(event interface{}) error

// EventConsumer handles consuming events from Kafka
type EventConsumer struct {
	consumer *kafka.Consumer
	handlers map[schema.EventType]EventHandler
}

// Config holds consumer configuration
type Config struct {
	BootstrapServers string
	GroupID          string
	Topics           []string
	AutoOffsetReset  string // "earliest" or "latest"
}

// NewEventConsumer creates a new Kafka consumer
func NewEventConsumer(cfg Config) (*EventConsumer, error) {
	if cfg.AutoOffsetReset == "" {
		cfg.AutoOffsetReset = "earliest"
	}

	config := &kafka.ConfigMap{
		"bootstrap.servers":  cfg.BootstrapServers,
		"group.id":           cfg.GroupID,
		"auto.offset.reset":  cfg.AutoOffsetReset,
		"enable.auto.commit": true,
		"session.timeout.ms": 6000,
	}

	consumer, err := kafka.NewConsumer(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	// Subscribe to topics
	err = consumer.SubscribeTopics(cfg.Topics, nil)
	if err != nil {
		consumer.Close()
		return nil, fmt.Errorf("failed to subscribe to topics: %w", err)
	}

	return &EventConsumer{
		consumer: consumer,
		handlers: make(map[schema.EventType]EventHandler),
	}, nil
}

// RegisterHandler registers a handler for a specific event type
func (c *EventConsumer) RegisterHandler(eventType schema.EventType, handler EventHandler) {
	c.handlers[eventType] = handler
}

// Start begins consuming events
func (c *EventConsumer) Start() error {
	log.Println("Starting event consumer...")

	for {
		msg, err := c.consumer.ReadMessage(-1)
		if err != nil {
			log.Printf("Consumer error: %v\n", err)
			continue
		}

		if err := c.processMessage(msg); err != nil {
			log.Printf("Failed to process message: %v\n", err)
			// Continue processing despite errors
			continue
		}
	}
}

// processMessage handles a single Kafka message
func (c *EventConsumer) processMessage(msg *kafka.Message) error {
	// Parse base event to determine type
	var baseEvent schema.BaseEvent
	if err := json.Unmarshal(msg.Value, &baseEvent); err != nil {
		return fmt.Errorf("failed to unmarshal base event: %w", err)
	}

	log.Printf("Processing event: ID=%s Type=%s Platform=%s\n",
		baseEvent.EventID, baseEvent.EventType, baseEvent.Platform)

	// Get the appropriate handler
	handler, exists := c.handlers[baseEvent.EventType]
	if !exists {
		log.Printf("No handler registered for event type: %s\n", baseEvent.EventType)
		return nil // Not an error, just skip
	}

	// Unmarshal to the specific event type
	eventInterface := schema.GetEventTypeInterface(baseEvent.EventType)
	if err := json.Unmarshal(msg.Value, eventInterface); err != nil {
		return fmt.Errorf("failed to unmarshal event to type %s: %w", baseEvent.EventType, err)
	}

	// Call the handler
	if err := handler(eventInterface); err != nil {
		return fmt.Errorf("handler failed for event %s: %w", baseEvent.EventID, err)
	}

	log.Printf("Successfully processed event: %s\n", baseEvent.EventID)
	return nil
}

// Close shuts down the consumer
func (c *EventConsumer) Close() error {
	return c.consumer.Close()
}
