package auth

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// Role defines access levels
type Role string

const (
	RoleAdmin    Role = "admin"
	RoleProducer Role = "producer"
	RoleConsumer Role = "consumer"
)

// Client represents an OAuth client
type Client struct {
	ClientID     string   `json:"client_id"`
	ClientSecret string   `json:"client_secret"` // Hashed
	Name         string   `json:"name"`
	Platform     string   `json:"platform"` // scraper, code, scan, review
	Role         Role     `json:"role"`
	Scopes       []string `json:"scopes"`
	Active       bool     `json:"active"`
}

// TokenClaims represents JWT token claims
type TokenClaims struct {
	ClientID string   `json:"client_id"`
	Platform string   `json:"platform"`
	Role     Role     `json:"role"`
	Scopes   []string `json:"scopes"`
	jwt.RegisteredClaims
}

// AuthService handles OAuth 2.0 operations
type AuthService struct {
	privateKey *rsa.PrivateKey
	publicKey  *rsa.PublicKey
	clients    map[string]*Client
}

// NewAuthService creates a new auth service
func NewAuthService() (*AuthService, error) {
	// Generate RSA key pair
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, fmt.Errorf("failed to generate RSA key: %w", err)
	}

	return &AuthService{
		privateKey: privateKey,
		publicKey:  &privateKey.PublicKey,
		clients:    make(map[string]*Client),
	}, nil
}

// RegisterClient creates a new OAuth client
func (s *AuthService) RegisterClient(name, platform string, role Role, scopes []string) (*Client, string, error) {
	// Generate client ID
	clientID := fmt.Sprintf("client_%s_%d", platform, time.Now().Unix())

	// Generate client secret
	secretBytes := make([]byte, 32)
	if _, err := rand.Read(secretBytes); err != nil {
		return nil, "", fmt.Errorf("failed to generate secret: %w", err)
	}
	clientSecret := base64.URLEncoding.EncodeToString(secretBytes)

	// Hash the secret
	hashedSecret, err := bcrypt.GenerateFromPassword([]byte(clientSecret), bcrypt.DefaultCost)
	if err != nil {
		return nil, "", fmt.Errorf("failed to hash secret: %w", err)
	}

	client := &Client{
		ClientID:     clientID,
		ClientSecret: string(hashedSecret),
		Name:         name,
		Platform:     platform,
		Role:         role,
		Scopes:       scopes,
		Active:       true,
	}

	s.clients[clientID] = client

	// Return the client and the unhashed secret (only time it's visible)
	return client, clientSecret, nil
}

// ValidateCredentials checks client credentials
func (s *AuthService) ValidateCredentials(clientID, clientSecret string) (*Client, error) {
	client, exists := s.clients[clientID]
	if !exists {
		return nil, fmt.Errorf("invalid client_id")
	}

	if !client.Active {
		return nil, fmt.Errorf("client is inactive")
	}

	// Verify secret
	err := bcrypt.CompareHashAndPassword([]byte(client.ClientSecret), []byte(clientSecret))
	if err != nil {
		return nil, fmt.Errorf("invalid client_secret")
	}

	return client, nil
}

// GenerateToken creates a JWT access token
func (s *AuthService) GenerateToken(client *Client) (string, error) {
	now := time.Now()
	expiresAt := now.Add(1 * time.Hour)

	claims := TokenClaims{
		ClientID: client.ClientID,
		Platform: client.Platform,
		Role:     client.Role,
		Scopes:   client.Scopes,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    "eventid-auth",
			Subject:   client.ClientID,
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(expiresAt),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodRS256, claims)
	tokenString, err := token.SignedString(s.privateKey)
	if err != nil {
		return "", fmt.Errorf("failed to sign token: %w", err)
	}

	return tokenString, nil
}

// ValidateToken verifies a JWT token
func (s *AuthService) ValidateToken(tokenString string) (*TokenClaims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &TokenClaims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return s.publicKey, nil
	})

	if err != nil {
		return nil, fmt.Errorf("failed to parse token: %w", err)
	}

	if claims, ok := token.Claims.(*TokenClaims); ok && token.Valid {
		return claims, nil
	}

	return nil, fmt.Errorf("invalid token")
}

// GetJWKS returns the JSON Web Key Set for token validation
func (s *AuthService) GetJWKS() (map[string]interface{}, error) {
	// Export public key
	pubKeyBytes, err := x509.MarshalPKIXPublicKey(s.publicKey)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal public key: %w", err)
	}

	pubKeyPEM := pem.EncodeToMemory(&pem.Block{
		Type:  "RSA PUBLIC KEY",
		Bytes: pubKeyBytes,
	})

	// Create JWKS response
	jwks := map[string]interface{}{
		"keys": []map[string]interface{}{
			{
				"kty": "RSA",
				"use": "sig",
				"alg": "RS256",
				"n":   base64.RawURLEncoding.EncodeToString(s.publicKey.N.Bytes()),
				"e":   base64.RawURLEncoding.EncodeToString(big2bytes(s.publicKey.E)),
			},
		},
	}

	return jwks, nil
}

// GetPublicKeyPEM returns the public key in PEM format
func (s *AuthService) GetPublicKeyPEM() (string, error) {
	pubKeyBytes, err := x509.MarshalPKIXPublicKey(s.publicKey)
	if err != nil {
		return "", fmt.Errorf("failed to marshal public key: %w", err)
	}

	pubKeyPEM := pem.EncodeToMemory(&pem.Block{
		Type:  "RSA PUBLIC KEY",
		Bytes: pubKeyBytes,
	})

	return string(pubKeyPEM), nil
}

// big2bytes converts an int to bytes
func big2bytes(n int) []byte {
	if n == 0 {
		return []byte{0}
	}
	
	bytes := make([]byte, 0)
	for n > 0 {
		bytes = append([]byte{byte(n & 0xff)}, bytes...)
		n >>= 8
	}
	return bytes
}

// LoadClientsFromJSON loads clients from JSON data
func (s *AuthService) LoadClientsFromJSON(data []byte) error {
	var clients []*Client
	if err := json.Unmarshal(data, &clients); err != nil {
		return fmt.Errorf("failed to unmarshal clients: %w", err)
	}

	for _, client := range clients {
		s.clients[client.ClientID] = client
	}

	return nil
}

// GetClient retrieves a client by ID
func (s *AuthService) GetClient(clientID string) (*Client, error) {
	client, exists := s.clients[clientID]
	if !exists {
		return nil, fmt.Errorf("client not found: %s", clientID)
	}
	return client, nil
}
